export const getUpdates =  (setState) => {
  let client;
  try{
      var mqtt = require('mqtt');

      const options = {
          clientId:"mqttjs01",
          username:"steve",
          password:"password",
          clean:true
      };

      client =  mqtt.connect("mqtt://broker.emqx.io");
      // "broker.emqx.io"
      // var client = mqtt.connect("broker.emqx.io", options);


      client.on('message', function(topic, message, packet) {
          console.log("message is " + message);
          setState(message);
          console.log("topic is " + topic);
      });


      client.on("connect", function() {
          console.log("connected");
      });

      var topic_list=["AmbInt/sensors/pot","AmbInt/sensors/temp","AmbInt/sensors/int"];
      client.subscribe(topic_list,{qos:1});
      // var topic_o = {"AmbInt/sensors/pot":1,"AmbInt/sensors/temp":1,"AmbInt/sensors/int":1};
      // client.subscribe(topic_o);

    
      //handle errors
      client.on("error",function(error){
          console.log("Can't connect" + error);
          process.exit(1)
      });



  } catch (e) {
      console.log(e);
      //client.end();
  } 
};
